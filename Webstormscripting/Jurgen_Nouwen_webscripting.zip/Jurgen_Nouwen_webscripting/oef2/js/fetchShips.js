// naam: Jurgen Nouwen

window.addEventListener("load", handleWindowload);

function handleWindowload() {
    let url = 'http://localhost:3000/country/';
}

function handleGetShips() {
    let url = 'http://localhost:3000/ship/';
}
function makeButton(object){
    let select = document.getElementById("div_select");
    let item;
    for
    select.appendChild(item = document.createElement("option"));
    item = for
}

<select id="select_country">
    <option value ="1">England</option>
    <option value ="2">Holland</option>
    <option value ="3">France</option>
    <option value ="4">Russia</option>
</select>


let elements2 = document.querySelector( ".red" );